use 5.006;
use ExtUtils::MakeMaker;

WriteMakefile(
    NAME              => 'MyApp::Hello',
    VERSION_FROM      => 'lib/MyApp/Hello.pm',
    PREREQ_PM         => {
        'Test::Simple' => 0.44,
    },
    EXE_FILES         => ['script/myapp.pl'],
    LICENSE           => 'perl',
    ($] >= 5.005 ?     ## Add these new keywords supported since 5.005
      (ABSTRACT_FROM  => 'lib/MyApp/Hello.pm',
       AUTHOR         => 'Your Name <you@example.com>') : ()),
);