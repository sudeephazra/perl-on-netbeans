# My Perl Project

This is a simple Perl project demonstrating a basic "Hello World" program.

## Building the Project

To build the project, run:

```sh
perl Makefile.PL
make
```

## Running the Program
After building, you can run the program using:

```sh
./script/myapp.pl
```

## Running Tests
To run the tests, run:

```sh
make test
```

## Cleaning Up
To clean up the build artifacts, run:

```sh
make clean
```